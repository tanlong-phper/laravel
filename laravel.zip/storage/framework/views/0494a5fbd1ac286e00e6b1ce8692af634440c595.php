<style>
    .checkbox {vertical-align: middle; margin-top: -3px!important; margin-right: 6px!important;}
    .switch { margin-right:10px; display:inline-block; width:20px; height:20px; border:1px solid #ccc; text-align:center; line-height:20px; cursor: pointer;}
    .area_box li { list-style:none;}
</style>

<?php $__env->startSection('content'); ?>

    <div class="box">


        <!-- /.box-header -->
        <div class="box-body">

            <form action="<?php echo e(url('account/role/store')); ?>" method="post" class="js-ajax-form">
                <?php echo e(csrf_field()); ?>

            <div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">

                <h4 class="bg-info" style="padding:5px 10px; font-size:14px; overflow:hidden;">
                    <span style="line-height:34px;">新增角色</span>
                </h4>
                <div class="row">
                    <div class="col-sm-4">
                        <label><b>角色名称：</b><input type="text" name="name" class="form-control" placeholder=""></label>
                    </div>
                    <div class="col-sm-4">
                        <label><b>上一级角色：</b></label>
                        <select class="form-control" name="pid">
                            <option value="0">无</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($values->id); ?>"><?php echo e($values->name); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-sm-4">
                        <label><b>角色状态：</b></label>
                        <select class="form-control" name="status">
                            <option value="1">启用</option>
                            <option value="0">不启用</option>
                        </select>
                    </div>
                </div>

                

                <div class="row">
                    <div class="col-sm-9">
                        <b>功能权限：</b>
                        <label><input  class="checkbox checkbox-all" type="checkbox" name="" id="">全选</label>
                    </div>
                </div>



                <div class="area_box" style="border:1px solid #ccc; padding:20px;">
                    <ul class="one">
                        <?php $__currentLoopData = $menu_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv1_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><span class="switch">+</span><label><input class="checkbox one_checkout" type="checkbox" name="menu_role_id[]" value="<?php echo e($lv1_value['id']); ?>"><?php echo e($lv1_value['name']); ?></label>
                            <?php if(isset($lv1_value['sub'])): ?>
                                <ul class="two" style="display: none">
                                <?php $__currentLoopData = $lv1_value['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv2_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><span class="switch">+</span><label><input class="checkbox" type="checkbox" name="menu_role_id[]" value="<?php echo e($lv2_value['id']); ?>"><?php echo e($lv2_value['name']); ?></label>
                                    <?php if(isset($lv2_value['sub'])): ?>
                                        <ul class="three" style="display: none">
                                        <?php $__currentLoopData = $lv2_value['sub']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lv3_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><label><input class="checkbox" type="checkbox" name="menu_role_id[]" value="<?php echo e($lv3_value['area_id']); ?>"><?php echo e($lv3_value['name']); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>


            </div>


            <hr>
            <div class="row">
                <div class="col-sm-4">
                    <a href="<?php echo e(url('account/department')); ?>" type="button" class="btn btn-default">取消</a>
                    <button type="submit" class="btn btn-primary js-ajax-submit">确定</button>
                </div>

            </div>

            </form>
        </div>




        <!-- /.box-body -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(function (){

            $('.switch').click(function (){
                if ($(this).siblings('ul').css('display') == 'none') {
                    $(this).siblings('ul').slideDown(100).children('li');
                    if ($(this).parents('li').siblings('li').children('ul').css('display') == 'block') {
                        $(this).parents('li').siblings('li').children('ul').slideUp(100);
                    }
                    $(this).text('-');
                } else {
                    //控制自身菜单下子菜单隐藏
                    $(this).siblings('ul').slideUp(100);
                    //控制自身菜单下子菜单隐藏
                    $(this).siblings('ul').children('li').children('ul').slideUp(100);
                    $(this).text('+');
                }
            });

            $('.checkbox-all').click(function (){
                if($(this).is(':checked')){
                    $('.area_box .checkbox').attr('checked',true);
                }else{
                    $('.area_box .checkbox').attr('checked',false);
                }

            });

            $('.checkbox').change(function (){
                var checkout = $(this).parents('label').siblings('ul').children('li').children('label').children('.checkbox');

                if($(this).is(':checked')){
                    checkout.attr('checked',true);
                    checkout.parents('label').siblings('ul').children('li').children('label').children('.checkbox').attr('checked',true);
                }else{
                    checkout.attr('checked',false);
                    checkout.parents('label').siblings('ul').children('li').children('label').children('.checkbox').attr('checked',false);
                }
            });




            /*$('.a-link-menu').click(function() {
                if ($(this).siblings('ul').css('display') == 'none') {
                    $(this).siblings('ul').slideDown(100).children('li');
                    if ($(this).parents('li').siblings('li').children('ul').css('display') == 'block') {
                        $(this).parents('li').siblings('li').children('ul').slideUp(100);

                    }
                } else {
                    //控制自身菜单下子菜单隐藏
                    $(this).siblings('ul').slideUp(100);
                    //控制自身菜单下子菜单隐藏
                    $(this).siblings('ul').children('li').children('ul').slideUp(100);
                }
            });*/
        })
    </script>


    <?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>