<?php $__env->startSection('css'); ?>


<link rel="stylesheet" href="<?php echo e(asset('css/base.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/module.css')); ?>">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<div class="box">


    <!-- /.box-header -->
    <div class="box-body">


        <h4 class="bg-info" style="padding:5px 10px; font-size:14px; overflow:hidden;">
            <span style="line-height:34px;">新增分类</span>
        </h4>

        <?php if(session('error')): ?>
            <div class="alert alert-error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(url('category/menu/store')); ?>" method="post" class="form-horizontal form-submit" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">上一级菜单：</label>
                <div class="col-sm-4" style="padding-top:7px;">
                    <?php if(!empty($menu_list)): ?>
                        <select class="form-control" name="pid">
                            <option value="0">无</option>
                            <?php $__currentLoopData = $menu_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <?php else: ?>

                        <input type="hidden" name="pid" value="<?php echo e(isset($parent_cate->id) ? $parent_cate->id : 0); ?>">
                        <?php echo e(isset($parent_cate->name) ? $parent_cate->name : ''); ?>


                    <?php endif; ?>

                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">状态：</label>
                <div class="col-sm-4">
                    <select class="form-control" name="status">
                        <option value="1">启用</option>
                        <option value="0">禁用</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">菜单排序：</label>
                <div class="col-sm-4">
                    <input type="text" name="sort_number" class="form-control" id="inputEmail3" value="0">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">菜单名称：<span style="color:red">*</span></label>
                <div class="col-sm-4">
                    <input type="text" name="name" required id="class_name" class="form-control" id="inputEmail3" placeholder="">
                </div>
            </div>
            <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">菜单URL：</label>
                <div class="col-sm-4">
                    <input type="text" name="url" class="form-control" id="inputEmail3" placeholder="">
                </div>
            </div>

            <div class="row">
                <div class="col-sm-4">

                    <a href="javascript:window.history.go(-1)" type="button" class="btn btn-default">取消</a>
                    <button type="submit" class="btn btn-primary js-ajax-submit">确定</button>
                </div>
            </div>

        </form>


    </div>




    <!-- /.box-body -->
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

    <link rel="stylesheet" type="text/css" href="/static/webuploader/0.1.5/style.css"/>
    <link rel="stylesheet" type="text/css" href="/static/webuploader/0.1.5/webuploader.css"/>
    <script type="text/javascript" src="/static/webuploader/0.1.5/webuploader.min.js"></script>

    <script>
        $(function (){
            /*$('.form-submit').submit(function (){
                if($("#class_name").val() == ''){
                    layer.msg('栏目名称不能为空！',{ icon:10});
                    return false;
                }
            })*/



    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>