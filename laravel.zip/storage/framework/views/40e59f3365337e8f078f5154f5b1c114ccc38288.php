
<?php $__currentLoopData = $tree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<dl class="cate-item">
		<dt class="cf">
			<form action="<?php echo e(url('category/menu/edit')); ?>" method="post">
				<div class="btn-toolbar opt-btn cf">
					

					<a class="layer-delete" href="<?php echo e(url('category/menu/destroy',['id'=>$values['id']])); ?>">删除</a>
				</div>
				<div class="fold"><i></i></div>
				<div class="order"><?php echo e($values['id']); ?></div>
				<div class="order"><input type="text" name="sort_number" class="text input-mini" value="<?php echo e($values['sort_number']); ?>"></div>
				<div class="order">
					
				</div>
				<div class="name">
					<span class="tab-sign"></span>
					<input type="hidden" name="id" value="<?php echo e($values['id']); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="text" name="name" class="text" value="<?php echo e($values['name']); ?>">
					<input type="text" name="url" class="text" value="<?php echo e($values['url']); ?>">
					<a class="add-sub-cate" title="添加子分类" href="<?php echo e(url('category/menu/create',['pid'=>$values['id']])); ?> ">
						<i class="icon-add"></i>
					</a>
					<span class="help-inline msg"></span>
				</div>
			</form>
		</dt>
		<?php if(!empty($values['children'])): ?>
			<dd style="display:none;">
				<?php echo $__env->make('category.tree_menu', ['tree' => $values['children']], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			</dd>
		<?php endif; ?>
	</dl>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>