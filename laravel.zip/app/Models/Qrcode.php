<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Qrcode extends Base {
	protected $table = 'qrcode';
	
	
}