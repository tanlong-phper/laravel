<?php
namespace App\Models;


class VbuyProductImgModel extends Base {

	protected $table = 'tbuy_product_img';
	
}