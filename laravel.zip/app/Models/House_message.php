<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class House_message extends Base
{
	protected $table = 'house_message';//房源信息表
}