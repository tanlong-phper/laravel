<?php

namespace App\Models;

use DB;
use Illuminate\Database\Eloquent\Model;

class Base extends Model
{
    // 是否被自动维护时间戳，关闭
    public $timestamps = false;


}
