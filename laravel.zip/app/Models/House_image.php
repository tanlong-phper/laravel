<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class House_image extends Base
{
	protected $table = 'house_image';//房源信息表
}