<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Base
{
    //
//    protected $table = 'admin_menus';
}
