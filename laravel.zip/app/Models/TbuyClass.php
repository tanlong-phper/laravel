<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TbuyClass extends Base
{
    //

    // 是否被自动维护时间戳，关闭
    public $timestamps = false;

    protected $table = 'tbuy_class';
    
}
