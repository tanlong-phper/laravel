<?php
/**
 * 常量定义
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/2/14
 * Time: 15:46
 */
#用户登录加密字符串
define('SECURITY_CODE','6A61750BB30490604B7DF6FD8DA9FA8E');

#图片服务器地址
define('PIC_SERVICE','http://file.aaaui.com/');

#测试服务器接口地址
define('TEST_URL','http://api2.hlqqg.cn/');

#正式服务器接口地址
define('OFFICIAL_URL','http://api2.aaaui.com/');