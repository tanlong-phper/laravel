@extends('layouts.default')

@section('css')


@stop

@section('content')

    <div class="box">
        <div class="box-body">

        </div>
    </div>

@stop

@section('js')


@stop


